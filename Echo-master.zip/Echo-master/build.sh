#!/bin/sh
z80asm -i src-z80/build.z80 -o prog-z80.bin
