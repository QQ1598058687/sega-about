print("hello, world!")
