DLL unsigned char* vgmcmp_optimize(unsigned char* src,int &size);
DLL const char*    vgmcmp_about(void);
DLL void           vgmcmp_free(unsigned char *data);