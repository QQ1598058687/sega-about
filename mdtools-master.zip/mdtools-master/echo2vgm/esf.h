#ifndef ESF_H
#define ESF_H

int parse_esf(const char *);

#endif
