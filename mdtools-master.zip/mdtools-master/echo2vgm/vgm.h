#ifndef VGM_H
#define VGM_H

int save_vgm(const char *);

#endif
