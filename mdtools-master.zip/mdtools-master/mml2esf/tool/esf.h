#ifndef ESF_H
#define ESF_H

// Function prototypes
int generate_esf(const char *);

#endif
