#ifndef MML_H
#define MML_H

// Function prototypes
int parse_mml(const char *);

#endif
