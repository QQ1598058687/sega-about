RIFFStrip v1.01
(C) 2003 By Marco Pontello

Info:
http://mark0.ngi.it/soft-riffstrip.html


RIFFStrip � una semplice utility per rimuovere l'header RIFF-WAVE da, ad
esempio, un file .MP3 incapsulato in un file .WAV. Processa correttamente
tutta la catena di chunks che si possono susseguire nel WAV, e dovrebbe
poter funzionare regolarmente con qualasisi tipo di stream audio: MP3,
AC3, etc.

L'uso � assolutamente banale: basta indicare il file da elaborare, per
ottenere un corrispondente file con aggiunta l'estensione ".stripped".

Sistema richiesto: Win 9x/ME/NT/2K/XP


