RIFFStrip v1.01
(C) 2003 By Marco Pontello

Info:
http://mark0.ngi.it/soft-riffstrip-e.html


RIFFStrip is a simple utility for removing the RIFF-WAVE header from,
for ex., a .MP3 file contained in a WAV file. It process all the chunks
chain on the WAV file, and should work correctly with any type of audio
stream: MP3, AC3, etc.

Usage is very simple. Just supply the file name of a WAV file, to obtain
a corresponding file with the added extension ".stripped".

Required System: Win 9x/ME/NT/2K/XP


